namespace Game;

public class BricksBlock : PaintedCubeBlock
{
	public const int Index = 73;

	public BricksBlock()
		: base(39)
	{
	}
}
