namespace Game;

public struct AnalyticsParameter
{
	public string Name;

	public string Value;

	public AnalyticsParameter(string name, string value)
	{
		Name = name;
		Value = value;
	}
}
