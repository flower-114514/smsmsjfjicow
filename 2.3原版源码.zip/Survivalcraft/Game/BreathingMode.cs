namespace Game;

public enum BreathingMode
{
	Air,
	Water
}
