namespace Game;

public class BasaltStairsBlock : StairsBlock
{
	public const int Index = 96;

	public BasaltStairsBlock()
		: base(40)
	{
	}
}
