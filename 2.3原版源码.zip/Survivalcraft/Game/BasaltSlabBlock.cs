namespace Game;

public class BasaltSlabBlock : SlabBlock
{
	public const int Index = 95;

	public BasaltSlabBlock()
		: base(40, 67)
	{
	}
}
