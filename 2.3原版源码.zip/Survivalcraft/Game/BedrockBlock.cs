namespace Game;

public class BedrockBlock : CubeBlock
{
	public const int Index = 1;
}
