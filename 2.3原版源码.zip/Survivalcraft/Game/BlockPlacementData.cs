namespace Game;

public struct BlockPlacementData
{
	public int Value;

	public CellFace CellFace;
}
