namespace Game;

public class ActiveExternalContentInfo
{
	public string Address;

	public string DisplayName;

	public ExternalContentType Type;
}
