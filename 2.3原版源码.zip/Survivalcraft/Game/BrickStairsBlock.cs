namespace Game;

public class BrickStairsBlock : StairsBlock
{
	public const int Index = 76;

	public BrickStairsBlock()
		: base(39)
	{
	}
}
