using System.Diagnostics;

namespace Game;

[Conditional("DEBUG")]
public class AverageTimeDebugItemAttribute : DebugItemAttribute
{
}
