namespace Game;

public class BirchWoodBlock : WoodBlock
{
	public const int Index = 10;

	public BirchWoodBlock()
		: base(21, 117)
	{
	}
}
