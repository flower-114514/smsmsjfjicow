namespace Game;

public abstract class BucketBlock : Block
{
	public override void GenerateTerrainVertices(BlockGeometryGenerator generator, TerrainGeometry geometry, int value, int x, int y, int z)
	{
	}
}
