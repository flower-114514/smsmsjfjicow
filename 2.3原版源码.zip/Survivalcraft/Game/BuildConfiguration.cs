namespace Game;

public enum BuildConfiguration
{
	Debug,
	Release
}
