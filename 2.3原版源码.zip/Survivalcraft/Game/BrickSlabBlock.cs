namespace Game;

public class BrickSlabBlock : SlabBlock
{
	public const int Index = 75;

	public BrickSlabBlock()
		: base(39, 73)
	{
	}
}
