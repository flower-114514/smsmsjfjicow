namespace Game;

public enum AimState
{
	InProgress,
	Cancelled,
	Completed
}
