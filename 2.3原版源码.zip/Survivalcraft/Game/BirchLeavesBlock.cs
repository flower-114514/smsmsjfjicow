namespace Game;

public class BirchLeavesBlock : LeavesBlock
{
	public const int Index = 13;

	public BirchLeavesBlock()
		: base(BlockColorsMap.BirchLeavesColorsMap)
	{
	}
}
