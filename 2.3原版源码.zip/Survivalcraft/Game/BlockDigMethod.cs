namespace Game;

public enum BlockDigMethod
{
	None,
	Shovel,
	Quarry,
	Hack
}
