namespace Game;

public struct BlockDropValue
{
	public int Value;

	public int Count;
}
