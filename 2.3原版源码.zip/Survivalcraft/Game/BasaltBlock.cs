namespace Game;

public class BasaltBlock : PaintedCubeBlock
{
	public const int Index = 67;

	public BasaltBlock()
		: base(40)
	{
	}
}
