using System;
using System.Collections.Generic;
using Engine;
using TemplatesDatabase;

namespace GameEntitySystem;

public abstract class Component : IDisposable
{
	private Entity m_entity;

	private ValuesDictionary m_valuesDictionary;

	public ValuesDictionary ValuesDictionary => m_valuesDictionary;

	public Entity Entity => m_entity;

	public Project Project => m_entity.Project;

	public bool IsAddedToProject => m_entity.IsAddedToProject;

	public virtual IEnumerable<Entity> GetOwnedEntities()
	{
		return ReadOnlyList<Entity>.Empty;
	}

	protected internal virtual void OnEntityAdded()
	{
	}

	protected internal virtual void OnEntityRemoved()
	{
	}

	protected internal virtual void Load(ValuesDictionary valuesDictionary, IdToEntityMap idToEntityMap)
	{
	}

	protected internal virtual void Save(ValuesDictionary valuesDictionary, EntityToIdMap entityToIdMap)
	{
	}

	public virtual void Dispose()
	{
	}

	internal void Initialize(Entity entity, ValuesDictionary valuesDictionary)
	{
		if (valuesDictionary.DatabaseObject.Type != entity.Project.GameDatabase.MemberComponentTemplateType)
		{
			throw new InvalidOperationException("ValuesDictionary has invalid type.");
		}
		m_entity = entity;
		m_valuesDictionary = valuesDictionary;
	}
}
