using System;
using Engine.Serialization;

namespace TemplatesDatabase;

[HumanReadableConverter(new Type[] { typeof(ProceduralValue) })]
public class ProceduralValueStringConverter : IHumanReadableConverter
{
	public string ConvertToString(object value)
	{
		return ((ProceduralValue)value).Procedure;
	}

	public object ConvertFromString(Type type, string data)
	{
		ProceduralValue proceduralValue = default(ProceduralValue);
		proceduralValue.Procedure = data;
		return proceduralValue;
	}
}
