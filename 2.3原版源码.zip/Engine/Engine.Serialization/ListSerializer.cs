using System.Collections.Generic;

namespace Engine.Serialization;

internal class ListSerializer<T> : ISerializer<List<T>>
{
	public void Serialize(InputArchive archive, ref List<T> value)
	{
		if (value == null)
		{
			value = new List<T>();
		}
		else
		{
			value.Clear();
		}
		archive.SerializeCollection(null, value);
	}

	public void Serialize(OutputArchive archive, List<T> value)
	{
		archive.SerializeCollection(null, (T _003Cp0_003E) => "e", value);
	}
}
