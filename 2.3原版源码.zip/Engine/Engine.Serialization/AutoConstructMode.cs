namespace Engine.Serialization;

public enum AutoConstructMode
{
	NotSet,
	No,
	Yes
}
