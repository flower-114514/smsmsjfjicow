using System;
using System.Collections.Generic;

namespace Engine.Serialization;

internal class ArraySerializer<T>
{
	public void Serialize(InputArchive archive, ref T[] value)
	{
		List<T> list = new List<T>();
		archive.SerializeCollection(null, list);
		if (value == null)
		{
			value = list.ToArray();
			return;
		}
		if (list.Count != value.Length)
		{
			throw new InvalidOperationException("Serializing into an existing array with invalid length.");
		}
		for (int i = 0; i < value.Length; i++)
		{
			value.SetValue(list[i], i);
		}
	}

	public void Serialize(OutputArchive archive, T[] value)
	{
		archive.SerializeCollection(null, (T _003Cp0_003E) => "e", value);
	}
}
