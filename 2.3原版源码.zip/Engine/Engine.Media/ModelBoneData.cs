namespace Engine.Media;

public class ModelBoneData
{
	public string Name;

	public int ParentBoneIndex;

	public Matrix Transform;
}
