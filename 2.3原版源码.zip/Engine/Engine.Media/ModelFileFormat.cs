namespace Engine.Media;

public enum ModelFileFormat
{
	Collada
}
