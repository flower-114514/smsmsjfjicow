namespace Engine.Media;

public class ModelMeshPartData
{
	public int BuffersDataIndex;

	public int StartIndex;

	public int IndicesCount;

	public BoundingBox BoundingBox;
}
