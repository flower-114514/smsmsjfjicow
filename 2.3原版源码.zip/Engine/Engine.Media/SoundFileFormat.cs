namespace Engine.Media;

public enum SoundFileFormat
{
	Wav,
	Ogg
}
