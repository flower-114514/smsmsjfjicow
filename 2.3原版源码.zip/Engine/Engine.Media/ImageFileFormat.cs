namespace Engine.Media;

public enum ImageFileFormat
{
	Bmp,
	Png,
	Jpg
}
