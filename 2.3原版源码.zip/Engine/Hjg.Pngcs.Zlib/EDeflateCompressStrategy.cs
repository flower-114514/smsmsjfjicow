namespace Hjg.Pngcs.Zlib;

internal enum EDeflateCompressStrategy
{
	Filtered,
	Huffman,
	Default
}
