namespace Engine.Input;

public enum GamePadTrigger
{
	Left,
	Right
}
