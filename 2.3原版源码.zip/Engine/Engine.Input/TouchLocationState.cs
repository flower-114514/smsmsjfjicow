namespace Engine.Input;

public enum TouchLocationState
{
	Pressed,
	Moved,
	Released
}
