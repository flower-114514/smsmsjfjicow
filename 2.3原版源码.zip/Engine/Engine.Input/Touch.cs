using System;
using System.Collections.Generic;
using Android.Views;

namespace Engine.Input;

public static class Touch
{
	private static List<TouchLocation> m_touchLocations = new List<TouchLocation>();

	public static ReadOnlyList<TouchLocation> TouchLocations => new ReadOnlyList<TouchLocation>(m_touchLocations);

	public static event Action<TouchLocation> TouchPressed;

	public static event Action<TouchLocation> TouchReleased;

	public static event Action<TouchLocation> TouchMoved;

	internal static void Initialize()
	{
	}

	internal static void Dispose()
	{
	}

	internal static void HandleTouchEvent(MotionEvent e)
	{
		if (e.ActionMasked == MotionEventActions.Down || e.ActionMasked == MotionEventActions.Pointer1Down)
		{
			int pointerId = e.GetPointerId(e.ActionIndex);
			float x = e.GetX(e.ActionIndex);
			float y = e.GetY(e.ActionIndex);
			ProcessTouchPressed(pointerId, new Vector2(x, y));
		}
		else if (e.ActionMasked == MotionEventActions.Move)
		{
			for (int i = 0; i < e.PointerCount; i++)
			{
				int pointerId2 = e.GetPointerId(i);
				float x2 = e.GetX(i);
				float y2 = e.GetY(i);
				ProcessTouchMoved(pointerId2, new Vector2(x2, y2));
			}
		}
		else if (e.ActionMasked == MotionEventActions.Up || e.ActionMasked == MotionEventActions.Pointer1Up || e.ActionMasked == MotionEventActions.Cancel || e.ActionMasked == MotionEventActions.Outside)
		{
			int pointerId3 = e.GetPointerId(e.ActionIndex);
			float x3 = e.GetX(e.ActionIndex);
			float y3 = e.GetY(e.ActionIndex);
			ProcessTouchReleased(pointerId3, new Vector2(x3, y3));
		}
	}

	public static void Clear()
	{
		m_touchLocations.Clear();
	}

	internal static void BeforeFrame()
	{
	}

	internal static void AfterFrame()
	{
		int num = 0;
		while (num < m_touchLocations.Count)
		{
			if (m_touchLocations[num].State == TouchLocationState.Released)
			{
				m_touchLocations.RemoveAt(num);
				continue;
			}
			if (m_touchLocations[num].ReleaseQueued)
			{
				m_touchLocations[num] = new TouchLocation
				{
					Id = m_touchLocations[num].Id,
					Position = m_touchLocations[num].Position,
					State = TouchLocationState.Released
				};
			}
			else if (m_touchLocations[num].State == TouchLocationState.Pressed)
			{
				m_touchLocations[num] = new TouchLocation
				{
					Id = m_touchLocations[num].Id,
					Position = m_touchLocations[num].Position,
					State = TouchLocationState.Moved
				};
			}
			num++;
		}
	}

	private static int FindTouchLocationIndex(int id)
	{
		for (int i = 0; i < m_touchLocations.Count; i++)
		{
			if (m_touchLocations[i].Id == id)
			{
				return i;
			}
		}
		return -1;
	}

	private static void ProcessTouchPressed(int id, Vector2 position)
	{
		ProcessTouchMoved(id, position);
	}

	private static void ProcessTouchMoved(int id, Vector2 position)
	{
		if (!Window.IsActive || Keyboard.IsKeyboardVisible)
		{
			return;
		}
		int num = FindTouchLocationIndex(id);
		if (num >= 0)
		{
			if (m_touchLocations[num].State == TouchLocationState.Moved)
			{
				m_touchLocations[num] = new TouchLocation
				{
					Id = id,
					Position = position,
					State = TouchLocationState.Moved
				};
			}
			if (Touch.TouchMoved != null)
			{
				Touch.TouchMoved(m_touchLocations[num]);
			}
		}
		else
		{
			m_touchLocations.Add(new TouchLocation
			{
				Id = id,
				Position = position,
				State = TouchLocationState.Pressed
			});
			if (Touch.TouchPressed != null)
			{
				Touch.TouchPressed(m_touchLocations[m_touchLocations.Count - 1]);
			}
		}
	}

	private static void ProcessTouchReleased(int id, Vector2 position)
	{
		if (!Window.IsActive || Keyboard.IsKeyboardVisible)
		{
			return;
		}
		int num = FindTouchLocationIndex(id);
		if (num >= 0)
		{
			if (m_touchLocations[num].State == TouchLocationState.Pressed)
			{
				m_touchLocations[num] = new TouchLocation
				{
					Id = id,
					Position = position,
					State = TouchLocationState.Pressed,
					ReleaseQueued = true
				};
			}
			else
			{
				m_touchLocations[num] = new TouchLocation
				{
					Id = id,
					Position = position,
					State = TouchLocationState.Released
				};
			}
			if (Touch.TouchReleased != null)
			{
				Touch.TouchReleased(m_touchLocations[num]);
			}
		}
	}
}
