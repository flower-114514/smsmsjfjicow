namespace Engine.Input;

public struct MouseButtonEvent
{
	public Point2 Position;

	public MouseButton Button;
}
