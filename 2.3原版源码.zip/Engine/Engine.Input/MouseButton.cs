namespace Engine.Input;

public enum MouseButton
{
	Left,
	Right,
	Middle
}
