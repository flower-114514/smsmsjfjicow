using System;

namespace Engine.Input;

public static class Mouse
{
	private static bool[] m_mouseButtonsDownArray;

	private static bool[] m_mouseButtonsDownOnceArray;

	private static bool[] m_mouseButtonsUpOnceArray;

	public static Point2 MouseMovement { get; private set; }

	public static int MouseWheelMovement { get; private set; }

	public static Point2? MousePosition { get; private set; }

	public static bool IsMouseVisible { get; set; }

	public static event Action<MouseEvent> MouseMove;

	public static event Action<MouseButtonEvent> MouseDown;

	public static event Action<MouseButtonEvent> MouseUp;

	public static void SetMousePosition(int x, int y)
	{
	}

	internal static void Initialize()
	{
	}

	internal static void Dispose()
	{
	}

	internal static void BeforeFrame()
	{
	}

	static Mouse()
	{
		m_mouseButtonsDownArray = new bool[Enum.GetValues(typeof(MouseButton)).Length];
		m_mouseButtonsDownOnceArray = new bool[Enum.GetValues(typeof(MouseButton)).Length];
		m_mouseButtonsUpOnceArray = new bool[Enum.GetValues(typeof(MouseButton)).Length];
		IsMouseVisible = true;
	}

	public static bool IsMouseButtonDown(MouseButton mouseButton)
	{
		return m_mouseButtonsDownArray[(int)mouseButton];
	}

	public static bool IsMouseButtonDownOnce(MouseButton mouseButton)
	{
		return m_mouseButtonsDownOnceArray[(int)mouseButton];
	}

	public static bool IsMouseButtonUpOnce(MouseButton mouseButton)
	{
		return m_mouseButtonsUpOnceArray[(int)mouseButton];
	}

	public static void Clear()
	{
		for (int i = 0; i < m_mouseButtonsDownArray.Length; i++)
		{
			m_mouseButtonsDownArray[i] = false;
			m_mouseButtonsDownOnceArray[i] = false;
			m_mouseButtonsUpOnceArray[i] = false;
		}
	}

	internal static void AfterFrame()
	{
		for (int i = 0; i < m_mouseButtonsDownOnceArray.Length; i++)
		{
			m_mouseButtonsDownOnceArray[i] = false;
			m_mouseButtonsUpOnceArray[i] = false;
		}
		if (!IsMouseVisible)
		{
			MousePosition = null;
		}
	}

	private static void ProcessMouseDown(MouseButton mouseButton, Point2 position)
	{
		if (Window.IsActive && !Keyboard.IsKeyboardVisible)
		{
			if (!MousePosition.HasValue)
			{
				ProcessMouseMove(position);
			}
			m_mouseButtonsDownArray[(int)mouseButton] = true;
			m_mouseButtonsDownOnceArray[(int)mouseButton] = true;
			if (IsMouseVisible && Mouse.MouseDown != null)
			{
				Mouse.MouseDown(new MouseButtonEvent
				{
					Button = mouseButton,
					Position = position
				});
			}
		}
	}

	private static void ProcessMouseUp(MouseButton mouseButton, Point2 position)
	{
		if (Window.IsActive && !Keyboard.IsKeyboardVisible)
		{
			if (!MousePosition.HasValue)
			{
				ProcessMouseMove(position);
			}
			m_mouseButtonsDownArray[(int)mouseButton] = false;
			m_mouseButtonsUpOnceArray[(int)mouseButton] = true;
			if (IsMouseVisible && Mouse.MouseUp != null)
			{
				Mouse.MouseUp(new MouseButtonEvent
				{
					Button = mouseButton,
					Position = position
				});
			}
		}
	}

	private static void ProcessMouseMove(Point2 position)
	{
		if (Window.IsActive && !Keyboard.IsKeyboardVisible && IsMouseVisible)
		{
			MousePosition = position;
			if (Mouse.MouseMove != null)
			{
				Mouse.MouseMove(new MouseEvent
				{
					Position = position
				});
			}
		}
	}
}
