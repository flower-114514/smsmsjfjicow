using System;
using Android.App;
using Android.Views;
using Android.Widget;

namespace Engine.Input;

public static class Keyboard
{
	private const double m_keyFirstRepeatTime = 0.2;

	private const double m_keyNextRepeatTime = 0.033;

	private static bool[] m_keysDownArray = new bool[Enum.GetValues(typeof(Key)).Length];

	private static bool[] m_keysDownOnceArray = new bool[Enum.GetValues(typeof(Key)).Length];

	private static double[] m_keysDownRepeatArray = new double[Enum.GetValues(typeof(Key)).Length];

	private static Key? m_lastKey;

	private static char? m_lastChar;

	public static Key? LastKey => m_lastKey;

	public static char? LastChar => m_lastChar;

	public static bool IsKeyboardVisible { get; private set; }

	public static bool BackButtonQuitsApp { get; set; }

	public static event Action<Key> KeyDown;

	public static event Action<Key> KeyUp;

	public static event Action<char> CharacterEntered;

	public static bool IsKeyDown(Key key)
	{
		return m_keysDownArray[(int)key];
	}

	public static bool IsKeyDownOnce(Key key)
	{
		return m_keysDownOnceArray[(int)key];
	}

	public static bool IsKeyDownRepeat(Key key)
	{
		double num = m_keysDownRepeatArray[(int)key];
		if (!(num < 0.0))
		{
			if (num != 0.0)
			{
				return Time.FrameStartTime >= num;
			}
			return false;
		}
		return true;
	}

	public static void ShowKeyboard(string title, string description, string defaultText, bool passwordMode, Action<string> enter, Action cancel)
	{
		if (title == null)
		{
			throw new ArgumentNullException("title");
		}
		if (description == null)
		{
			throw new ArgumentNullException("description");
		}
		if (defaultText == null)
		{
			throw new ArgumentNullException("defaultText");
		}
		if (IsKeyboardVisible)
		{
			return;
		}
		Clear();
		Touch.Clear();
		Mouse.Clear();
		IsKeyboardVisible = true;
		try
		{
			ShowKeyboardInternal(title, description, defaultText, passwordMode, delegate(string text)
			{
				Dispatcher.Dispatch(delegate
				{
					IsKeyboardVisible = false;
					if (enter != null)
					{
						enter(text ?? string.Empty);
					}
				});
			}, delegate
			{
				Dispatcher.Dispatch(delegate
				{
					IsKeyboardVisible = false;
					if (cancel != null)
					{
						cancel();
					}
				});
			});
		}
		catch
		{
			IsKeyboardVisible = false;
			throw;
		}
	}

	public static void Clear()
	{
		m_lastKey = null;
		m_lastChar = null;
		for (int i = 0; i < m_keysDownArray.Length; i++)
		{
			m_keysDownArray[i] = false;
			m_keysDownOnceArray[i] = false;
			m_keysDownRepeatArray[i] = 0.0;
		}
	}

	internal static void BeforeFrame()
	{
	}

	internal static void AfterFrame()
	{
		if (BackButtonQuitsApp && IsKeyDownOnce(Key.Back))
		{
			Window.Close();
		}
		m_lastKey = null;
		m_lastChar = null;
		for (int i = 0; i < m_keysDownOnceArray.Length; i++)
		{
			m_keysDownOnceArray[i] = false;
		}
		for (int j = 0; j < m_keysDownRepeatArray.Length; j++)
		{
			if (m_keysDownArray[j])
			{
				if (m_keysDownRepeatArray[j] < 0.0)
				{
					m_keysDownRepeatArray[j] = Time.FrameStartTime + 0.2;
				}
				else if (Time.FrameStartTime >= m_keysDownRepeatArray[j])
				{
					m_keysDownRepeatArray[j] = MathUtils.Max(Time.FrameStartTime, m_keysDownRepeatArray[j] + 0.033);
				}
			}
			else
			{
				m_keysDownRepeatArray[j] = 0.0;
			}
		}
	}

	private static bool ProcessKeyDown(Key key)
	{
		if (!Window.IsActive || IsKeyboardVisible)
		{
			return false;
		}
		m_lastKey = key;
		if (!m_keysDownArray[(int)key])
		{
			m_keysDownArray[(int)key] = true;
			m_keysDownOnceArray[(int)key] = true;
			m_keysDownRepeatArray[(int)key] = -1.0;
		}
		Keyboard.KeyDown?.Invoke(key);
		return true;
	}

	private static bool ProcessKeyUp(Key key)
	{
		if (!Window.IsActive || IsKeyboardVisible)
		{
			return false;
		}
		if (m_keysDownArray[(int)key])
		{
			m_keysDownArray[(int)key] = false;
		}
		Keyboard.KeyUp?.Invoke(key);
		return true;
	}

	private static bool ProcessCharacterEntered(char ch)
	{
		if (!Window.IsActive || IsKeyboardVisible)
		{
			return false;
		}
		m_lastChar = ch;
		Keyboard.CharacterEntered?.Invoke(ch);
		return true;
	}

	internal static void Initialize()
	{
	}

	internal static void Dispose()
	{
	}

	internal static void HandleKeyDown(Keycode keyCode)
	{
		Key key = TranslateKey(keyCode);
		if (key != (Key)(-1))
		{
			ProcessKeyDown(key);
		}
	}

	internal static void HandleKeyUp(Keycode keyCode)
	{
		Key key = TranslateKey(keyCode);
		if (key != (Key)(-1))
		{
			ProcessKeyUp(key);
		}
	}

	internal static void HandleKeyPress(int unicodeCharacter)
	{
		ProcessCharacterEntered((char)unicodeCharacter);
	}

	private static Key TranslateKey(Keycode keyCode)
	{
		return keyCode switch
		{
			Keycode.Home => Key.Home, 
			Keycode.Back => Key.Back, 
			Keycode.Num0 => Key.Number0, 
			Keycode.Num1 => Key.Number1, 
			Keycode.Num2 => Key.Number2, 
			Keycode.Num3 => Key.Number3, 
			Keycode.Num4 => Key.Number4, 
			Keycode.Num5 => Key.Number5, 
			Keycode.Num6 => Key.Number6, 
			Keycode.Num7 => Key.Number7, 
			Keycode.Num8 => Key.Number8, 
			Keycode.Num9 => Key.Number9, 
			Keycode.A => Key.A, 
			Keycode.B => Key.B, 
			Keycode.C => Key.C, 
			Keycode.D => Key.D, 
			Keycode.E => Key.E, 
			Keycode.F => Key.F, 
			Keycode.G => Key.G, 
			Keycode.H => Key.H, 
			Keycode.I => Key.I, 
			Keycode.J => Key.J, 
			Keycode.K => Key.K, 
			Keycode.L => Key.L, 
			Keycode.M => Key.M, 
			Keycode.N => Key.N, 
			Keycode.O => Key.O, 
			Keycode.P => Key.P, 
			Keycode.Q => Key.Q, 
			Keycode.R => Key.R, 
			Keycode.S => Key.S, 
			Keycode.T => Key.T, 
			Keycode.U => Key.U, 
			Keycode.V => Key.V, 
			Keycode.W => Key.W, 
			Keycode.X => Key.X, 
			Keycode.Y => Key.Y, 
			Keycode.Z => Key.Z, 
			Keycode.Comma => Key.Comma, 
			Keycode.Period => Key.Period, 
			Keycode.ShiftLeft => Key.Shift, 
			Keycode.ShiftRight => Key.Shift, 
			Keycode.Tab => Key.Tab, 
			Keycode.Space => Key.Space, 
			Keycode.Enter => Key.Enter, 
			Keycode.Del => Key.Delete, 
			Keycode.Minus => Key.Minus, 
			Keycode.LeftBracket => Key.LeftBracket, 
			Keycode.RightBracket => Key.RightBracket, 
			Keycode.Semicolon => Key.Semicolon, 
			Keycode.Slash => Key.Slash, 
			Keycode.Plus => Key.Plus, 
			Keycode.PageUp => Key.PageUp, 
			Keycode.PageDown => Key.PageDown, 
			Keycode.Escape => Key.Escape, 
			Keycode.ForwardDel => Key.Delete, 
			Keycode.CtrlLeft => Key.Control, 
			Keycode.CtrlRight => Key.Control, 
			Keycode.AltLeft => Key.Alt, 
			Keycode.AltRight => Key.Alt, 
			Keycode.CapsLock => Key.CapsLock, 
			Keycode.Insert => Key.Insert, 
			Keycode.F1 => Key.F1, 
			Keycode.F2 => Key.F2, 
			Keycode.F3 => Key.F3, 
			Keycode.F4 => Key.F4, 
			Keycode.F5 => Key.F5, 
			Keycode.F6 => Key.F6, 
			Keycode.F7 => Key.F7, 
			Keycode.F8 => Key.F8, 
			Keycode.F9 => Key.F9, 
			Keycode.F10 => Key.F10, 
			Keycode.F11 => Key.F11, 
			Keycode.F12 => Key.F12, 
			_ => (Key)(-1), 
		};
	}

	private static void ShowKeyboardInternal(string title, string description, string defaultText, bool passwordMode, Action<string> enter, Action cancel)
	{
		AlertDialog.Builder builder = new AlertDialog.Builder(Window.Activity);
		builder.SetTitle(title);
		builder.SetMessage(description);
		EditText editText = new EditText(Window.Activity);
		editText.Text = defaultText;
		builder.SetView(editText);
		builder.SetPositiveButton("Ok", delegate
		{
			enter(editText.Text);
		});
		builder.SetNegativeButton("Cancel", delegate
		{
			cancel();
		});
		AlertDialog alertDialog = builder.Create();
		alertDialog.DismissEvent += delegate
		{
			cancel();
		};
		alertDialog.CancelEvent += delegate
		{
			cancel();
		};
		alertDialog.Show();
	}
}
