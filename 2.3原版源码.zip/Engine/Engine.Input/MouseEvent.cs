namespace Engine.Input;

public struct MouseEvent
{
	public Point2 Position;
}
