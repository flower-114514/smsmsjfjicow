namespace Engine.Input;

public struct MultiMouseEvent
{
	public int MouseIndex;

	public Point2 Position;
}
