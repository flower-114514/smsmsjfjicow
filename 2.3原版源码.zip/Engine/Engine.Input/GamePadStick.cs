namespace Engine.Input;

public enum GamePadStick
{
	Left,
	Right
}
