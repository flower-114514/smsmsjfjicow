namespace FluxJpeg.Core.Filtering;

internal enum ResamplingFilters
{
	NearestNeighbor,
	LowpassAntiAlias
}
