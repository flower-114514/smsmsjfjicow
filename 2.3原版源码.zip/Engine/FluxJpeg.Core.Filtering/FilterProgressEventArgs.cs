using System;

namespace FluxJpeg.Core.Filtering;

internal class FilterProgressEventArgs : EventArgs
{
	public double Progress;
}
