namespace Engine.Graphics;

public enum DepthFormat
{
	None,
	Depth16,
	Depth24Stencil8
}
