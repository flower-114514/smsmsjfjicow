using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;
using OpenTK.Graphics.ES20;

namespace Engine.Graphics;

public class Shader : GraphicsResource
{
	internal struct ShaderAttributeData
	{
		public string Semantic;

		public int Location;
	}

	internal struct VertexAttributeData
	{
		public int Size;

		public All Type;

		public bool Normalize;

		public int Offset;
	}

	private Dictionary<string, ShaderParameter> m_parametersByName;

	internal ShaderParameter[] m_parameters;

	private string m_vertexShaderCode;

	private string m_pixelShaderCode;

	private ShaderMacro[] m_shaderMacros;

	internal int m_program;

	internal int m_vertexShader;

	internal int m_pixelShader;

	internal Dictionary<VertexDeclaration, VertexAttributeData[]> m_vertexAttributeDataByDeclaration = new Dictionary<VertexDeclaration, VertexAttributeData[]>();

	internal List<ShaderAttributeData> m_shaderAttributeData = new List<ShaderAttributeData>();

	private ShaderParameter m_glymulParameter;

	public object Tag { get; set; }

	public ReadOnlyList<ShaderParameter> Parameters => new ReadOnlyList<ShaderParameter>(m_parameters);

	public string DebugName
	{
		get
		{
			return string.Empty;
		}
		set
		{
		}
	}

	public ShaderParameter GetParameter(string name, bool allowNull = false)
	{
		if (!m_parametersByName.TryGetValue(name, out var value) && !allowNull)
		{
			throw new InvalidOperationException($"Parameter \"{name}\" not found.");
		}
		return value;
	}

	public override int GetGpuMemoryUsage()
	{
		return 16384;
	}

	protected virtual void PrepareForDrawingOverride()
	{
	}

	private void InitializeShader(string vertexShaderCode, string pixelShaderCode, ShaderMacro[] shaderMacros)
	{
		if (vertexShaderCode == null)
		{
			throw new ArgumentNullException("vertexShaderCode");
		}
		if (pixelShaderCode == null)
		{
			throw new ArgumentNullException("pixelShaderCode");
		}
		if (shaderMacros == null)
		{
			throw new ArgumentNullException("shaderMacros");
		}
		m_vertexShaderCode = vertexShaderCode;
		m_pixelShaderCode = pixelShaderCode;
		m_shaderMacros = (ShaderMacro[])shaderMacros.Clone();
	}

	public Shader(string vertexShaderCode, string pixelShaderCode, params ShaderMacro[] shaderMacros)
	{
		try
		{
			InitializeShader(vertexShaderCode, pixelShaderCode, shaderMacros);
			CompileShaders();
		}
		catch
		{
			Dispose();
			throw;
		}
	}

	public override void Dispose()
	{
		base.Dispose();
		DeleteShaders();
	}

	internal void PrepareForDrawing()
	{
		m_glymulParameter.SetValue((Display.RenderTarget != null) ? (-1f) : 1f);
		PrepareForDrawingOverride();
	}

	internal VertexAttributeData[] GetVertexAttribData(VertexDeclaration vertexDeclaration)
	{
		if (!m_vertexAttributeDataByDeclaration.TryGetValue(vertexDeclaration, out var value))
		{
			value = new VertexAttributeData[8];
			foreach (ShaderAttributeData shaderAttributeDatum in m_shaderAttributeData)
			{
				VertexElement vertexElement = null;
				for (int i = 0; i < vertexDeclaration.m_elements.Length; i++)
				{
					if (vertexDeclaration.m_elements[i].Semantic == shaderAttributeDatum.Semantic)
					{
						vertexElement = vertexDeclaration.m_elements[i];
						break;
					}
				}
				if (vertexElement != null)
				{
					value[shaderAttributeDatum.Location] = new VertexAttributeData
					{
						Size = vertexElement.Format.GetElementsCount(),
						Offset = vertexElement.Offset
					};
					GLWrapper.TranslateVertexElementFormat(vertexElement.Format, out value[shaderAttributeDatum.Location].Type, out value[shaderAttributeDatum.Location].Normalize);
					continue;
				}
				throw new InvalidOperationException($"VertexElement not found for shader attribute \"{shaderAttributeDatum.Semantic}\".");
			}
			m_vertexAttributeDataByDeclaration.Add(vertexDeclaration, value);
		}
		return value;
	}

	private static void ParseShaderMetadata(string shaderCode, Dictionary<string, string> semanticsByAttribute, Dictionary<string, string> samplersByTexture)
	{
		string[] array = shaderCode.Split('\n');
		for (int i = 0; i < array.Length; i++)
		{
			try
			{
				string text = array[i];
				text = text.Trim();
				if (!text.StartsWith("//"))
				{
					continue;
				}
				text = text.Substring(2).TrimStart();
				if (!text.StartsWith("<") || !text.EndsWith("/>"))
				{
					continue;
				}
				XElement xElement = XElement.Parse(text);
				if (xElement.Name == "Semantic")
				{
					if (xElement.Attribute("Attribute") == null)
					{
						throw new InvalidOperationException("Missing \"Attribute\" attribute in shader metadata.");
					}
					if (xElement.Attribute("Name") == null)
					{
						throw new InvalidOperationException("Missing \"Name\" attribute in shader metadata.");
					}
					semanticsByAttribute.Add(xElement.Attribute("Attribute").Value, xElement.Attribute("Name").Value);
					continue;
				}
				if (xElement.Name == "Sampler")
				{
					if (xElement.Attribute("Texture") == null)
					{
						throw new InvalidOperationException("Missing \"Texture\" attribute in shader metadata.");
					}
					if (xElement.Attribute("Name") == null)
					{
						throw new InvalidOperationException("Missing \"Name\" attribute in shader metadata.");
					}
					string value = xElement.Attribute("Texture").Value;
					string value2 = xElement.Attribute("Name").Value;
					if (samplersByTexture.TryGetValue(value, out var value3))
					{
						if (value3 != value2)
						{
							throw new InvalidOperationException($"Two different sampler definitions for texture \"{value}\", it is already defined to \"{value2}\".");
						}
					}
					else
					{
						samplersByTexture.Add(value, value2);
					}
					continue;
				}
				throw new InvalidOperationException("Unrecognized shader metadata node.");
			}
			catch (Exception ex)
			{
				throw new InvalidOperationException($"Error in shader metadata, line {i + 1}. {ex.Message}");
			}
		}
	}

	private string PrependShaderMacros(string shaderCode, ShaderMacro[] shaderMacros, bool isVertexShader)
	{
		string text = "#version 100" + Environment.NewLine;
		text = text + "#define GLSL" + Environment.NewLine;
		if (isVertexShader)
		{
			text = ((!Display.UseReducedZRange) ? (text + "#define OPENGL_POSITION_FIX gl_Position.y *= u_glymul; gl_Position.z = 2.0 * gl_Position.z - gl_Position.w;" + Environment.NewLine) : (text + "#define OPENGL_POSITION_FIX gl_Position.y *= u_glymul;" + Environment.NewLine));
			text = text + "uniform float u_glymul;" + Environment.NewLine;
		}
		foreach (ShaderMacro shaderMacro in shaderMacros)
		{
			text = text + "#define " + shaderMacro.Name + " " + shaderMacro.Value + Environment.NewLine;
		}
		text = text + "#line 1" + Environment.NewLine;
		return text + shaderCode;
	}

	internal override void HandleDeviceLost()
	{
		DeleteShaders();
	}

	internal override void HandleDeviceReset()
	{
		CompileShaders();
	}

	internal void CompileShaders()
	{
		DeleteShaders();
		Dictionary<string, string> dictionary = new Dictionary<string, string>();
		Dictionary<string, string> dictionary2 = new Dictionary<string, string>();
		ParseShaderMetadata(m_vertexShaderCode, dictionary, dictionary2);
		ParseShaderMetadata(m_pixelShaderCode, dictionary, dictionary2);
		string @string = PrependShaderMacros(m_vertexShaderCode, m_shaderMacros, isVertexShader: true);
		string string2 = PrependShaderMacros(m_pixelShaderCode, m_shaderMacros, isVertexShader: false);
		m_vertexShader = GL.CreateShader(All.VertexShader);
		GL.ShaderSource(m_vertexShader, @string);
		GL.CompileShader(m_vertexShader);
		GL.GetShader(m_vertexShader, OpenTK.Graphics.ES20.ShaderParameter.CompileStatus, out var @params);
		if (@params != 1)
		{
			string shaderInfoLog = GL.GetShaderInfoLog(m_vertexShader);
			throw new InvalidOperationException($"Error compiling vertex shader.\n{shaderInfoLog}");
		}
		m_pixelShader = GL.CreateShader(All.FragmentShader);
		GL.ShaderSource(m_pixelShader, string2);
		GL.CompileShader(m_pixelShader);
		GL.GetShader(m_pixelShader, OpenTK.Graphics.ES20.ShaderParameter.CompileStatus, out var params2);
		if (params2 != 1)
		{
			string shaderInfoLog2 = GL.GetShaderInfoLog(m_pixelShader);
			throw new InvalidOperationException($"Error compiling pixel shader.\n{shaderInfoLog2}");
		}
		m_program = GL.CreateProgram();
		GL.AttachShader(m_program, m_vertexShader);
		GL.AttachShader(m_program, m_pixelShader);
		GL.LinkProgram(m_program);
		GL.GetProgram(m_program, ProgramParameter.LinkStatus, out var params3);
		if (params3 != 1)
		{
			string programInfoLog = GL.GetProgramInfoLog(m_program);
			throw new InvalidOperationException($"Error linking program.\n{programInfoLog}");
		}
		GL.GetProgram(m_program, ProgramParameter.ActiveAttributes, out var params4);
		for (int i = 0; i < params4; i++)
		{
			StringBuilder stringBuilder = new StringBuilder(256);
			GL.GetActiveAttrib(m_program, i, stringBuilder.Capacity, out int _, out int _, out ActiveAttribType _, stringBuilder);
			string text = stringBuilder.ToString();
			int attribLocation = GL.GetAttribLocation(m_program, text);
			if (!dictionary.TryGetValue(text, out var value))
			{
				throw new InvalidOperationException($"Attribute \"{text}\" has no semantic defined in shader metadata.");
			}
			m_shaderAttributeData.Add(new ShaderAttributeData
			{
				Location = attribLocation,
				Semantic = value
			});
		}
		GL.GetProgram(m_program, ProgramParameter.ActiveUniforms, out var params5);
		List<ShaderParameter> list = new List<ShaderParameter>();
		Dictionary<string, ShaderParameter> dictionary3 = new Dictionary<string, ShaderParameter>();
		for (int j = 0; j < params5; j++)
		{
			StringBuilder stringBuilder2 = new StringBuilder(256);
			GL.GetActiveUniform(m_program, j, stringBuilder2.Capacity, out int _, out int size2, out ActiveUniformType type2, stringBuilder2);
			string text2 = stringBuilder2.ToString();
			int uniformLocation = GL.GetUniformLocation(m_program, text2);
			ShaderParameterType shaderParameterType = GLWrapper.TranslateActiveUniformType(type2);
			int num = text2.IndexOf('[');
			if (num >= 0)
			{
				text2 = text2.Remove(num, text2.Length - num);
			}
			ShaderParameter shaderParameter = new ShaderParameter(this, text2, shaderParameterType, size2);
			shaderParameter.Location = uniformLocation;
			dictionary3.Add(shaderParameter.Name, shaderParameter);
			list.Add(shaderParameter);
			if (shaderParameterType == ShaderParameterType.Texture2D)
			{
				if (!dictionary2.TryGetValue(shaderParameter.Name, out var value2))
				{
					throw new InvalidOperationException($"Texture \"{shaderParameter.Name}\" has no sampler defined in shader metadata.");
				}
				ShaderParameter shaderParameter2 = new ShaderParameter(this, value2, ShaderParameterType.Sampler2D, 1);
				shaderParameter2.Location = 2147483647;
				dictionary3.Add(value2, shaderParameter2);
				list.Add(shaderParameter2);
			}
		}
		if (m_parameters != null)
		{
			foreach (KeyValuePair<string, ShaderParameter> item in dictionary3)
			{
				if (m_parametersByName.TryGetValue(item.Key, out var value3))
				{
					value3.Location = item.Value.Location;
				}
			}
			ShaderParameter[] parameters = m_parameters;
			foreach (ShaderParameter shaderParameter3 in parameters)
			{
				shaderParameter3.IsChanged = true;
			}
		}
		else
		{
			m_parameters = list.ToArray();
			m_parametersByName = dictionary3;
		}
		m_glymulParameter = GetParameter("u_glymul");
		if (m_glymulParameter.Type != 0)
		{
			throw new InvalidOperationException("u_glymul parameter has invalid type.");
		}
	}

	internal void DeleteShaders()
	{
		if (m_program != 0)
		{
			if (m_vertexShader != 0)
			{
				GL.DetachShader(m_program, m_vertexShader);
			}
			if (m_pixelShader != 0)
			{
				GL.DetachShader(m_program, m_pixelShader);
			}
			GLWrapper.DeleteProgram(m_program);
			m_program = 0;
		}
		if (m_vertexShader != 0)
		{
			GL.DeleteShader(m_vertexShader);
			m_vertexShader = 0;
		}
		if (m_pixelShader != 0)
		{
			GL.DeleteShader(m_pixelShader);
			m_pixelShader = 0;
		}
	}
}
