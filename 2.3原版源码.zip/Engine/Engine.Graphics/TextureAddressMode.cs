namespace Engine.Graphics;

public enum TextureAddressMode
{
	Clamp,
	Wrap,
	MirrorWrap
}
