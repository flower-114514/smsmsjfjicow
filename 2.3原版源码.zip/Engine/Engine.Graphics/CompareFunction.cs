namespace Engine.Graphics;

public enum CompareFunction
{
	Always,
	Never,
	Less,
	LessEqual,
	Equal,
	GreaterEqual,
	Greater,
	NotEqual
}
