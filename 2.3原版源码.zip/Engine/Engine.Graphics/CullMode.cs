namespace Engine.Graphics;

public enum CullMode
{
	None,
	CullClockwise,
	CullCounterClockwise
}
