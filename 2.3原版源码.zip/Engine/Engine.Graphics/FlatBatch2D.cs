using System;
using System.Collections.Generic;

namespace Engine.Graphics;

public sealed class FlatBatch2D : BaseFlatBatch
{
	public FlatBatch2D()
	{
		base.DepthStencilState = DepthStencilState.None;
		base.RasterizerState = RasterizerState.CullNoneScissor;
		base.BlendState = BlendState.AlphaBlend;
	}

	public void QueueBatch(FlatBatch2D batch, Matrix? matrix = null, Color? color = null)
	{
		int count = LineVertices.Count;
		LineVertices.AddRange(batch.LineVertices);
		for (int i = 0; i < batch.LineIndices.Count; i++)
		{
			LineIndices.Add((ushort)(batch.LineIndices[i] + count));
		}
		int count2 = TriangleVertices.Count;
		TriangleVertices.AddRange(batch.TriangleVertices);
		for (int j = 0; j < batch.TriangleIndices.Count; j++)
		{
			TriangleIndices.Add((ushort)(batch.TriangleIndices[j] + count2));
		}
		if (matrix.HasValue && matrix != Matrix.Identity)
		{
			TransformLines(matrix.Value, count);
			TransformTriangles(matrix.Value, count2);
		}
		if (color.HasValue && color != Color.White)
		{
			TransformLinesColors(color.Value, count);
			TransformTrianglesColors(color.Value, count2);
		}
	}

	public void QueueLine(Vector2 p1, Vector2 p2, float depth, Color color)
	{
		int count = LineVertices.Count;
		LineVertices.Add(new VertexPositionColor(new Vector3(p1, depth), color));
		LineVertices.Add(new VertexPositionColor(new Vector3(p2, depth), color));
		LineIndices.Add((ushort)count);
		LineIndices.Add((ushort)(count + 1));
	}

	public void QueueLine(Vector2 p1, Vector2 p2, float depth, Color color1, Color color2)
	{
		int count = LineVertices.Count;
		LineVertices.Add(new VertexPositionColor(new Vector3(p1, depth), color1));
		LineVertices.Add(new VertexPositionColor(new Vector3(p2, depth), color2));
		LineIndices.Add((ushort)count);
		LineIndices.Add((ushort)(count + 1));
	}

	public void QueueLineStrip(IEnumerable<Vector2> points, float depth, Color color)
	{
		int count = LineVertices.Count;
		int num = 0;
		foreach (Vector2 point in points)
		{
			LineVertices.Add(new VertexPositionColor(new Vector3(point, depth), color));
			num++;
		}
		for (int i = 0; i < num - 1; i++)
		{
			LineIndices.Add((ushort)(count + i));
			LineIndices.Add((ushort)(count + i + 1));
		}
	}

	public void QueueRectangle(Vector2 corner1, Vector2 corner2, float depth, Color color)
	{
		int count = LineVertices.Count;
		LineVertices.Add(new VertexPositionColor(new Vector3(corner1.X, corner1.Y, depth), color));
		LineVertices.Add(new VertexPositionColor(new Vector3(corner1.X, corner2.Y, depth), color));
		LineVertices.Add(new VertexPositionColor(new Vector3(corner2.X, corner2.Y, depth), color));
		LineVertices.Add(new VertexPositionColor(new Vector3(corner2.X, corner1.Y, depth), color));
		LineIndices.Add((ushort)count);
		LineIndices.Add((ushort)(count + 1));
		LineIndices.Add((ushort)(count + 1));
		LineIndices.Add((ushort)(count + 2));
		LineIndices.Add((ushort)(count + 2));
		LineIndices.Add((ushort)(count + 3));
		LineIndices.Add((ushort)(count + 3));
		LineIndices.Add((ushort)count);
	}

	public void QueueEllipse(Vector2 center, Vector2 radius, float depth, Color color, int sides = 0, float startAngle = 0f, float endAngle = (float)Math.PI * 2f)
	{
		if (sides == 0)
		{
			sides = CalculateOptimalEllipseSides(radius, startAngle, endAngle);
		}
		Vector2 p = Vector2.Zero;
		for (int i = 0; i <= sides; i++)
		{
			float x = MathUtils.Lerp(startAngle, endAngle, (float)i / (float)sides);
			Vector2 vector = center + radius * new Vector2(MathUtils.Sin(x), 0f - MathUtils.Cos(x));
			if (i > 0)
			{
				QueueLine(p, vector, depth, color);
			}
			p = vector;
		}
	}

	public void QueueDisc(Vector2 center, Vector2 radius, float depth, Color color, int sides = 0, float startAngle = 0f, float endAngle = (float)Math.PI * 2f)
	{
		if (sides == 0)
		{
			sides = CalculateOptimalEllipseSides(radius, startAngle, endAngle);
		}
		Vector2 p = Vector2.Zero;
		for (int i = 0; i <= sides; i++)
		{
			float x = MathUtils.Lerp(startAngle, endAngle, (float)i / (float)sides);
			Vector2 vector = center + radius * new Vector2(MathUtils.Sin(x), 0f - MathUtils.Cos(x));
			if (i > 0)
			{
				QueueTriangle(p, vector, center, depth, color);
			}
			p = vector;
		}
	}

	public void QueueDisc(Vector2 center, Vector2 outerRadius, Vector2 innerRadius, float depth, Color outerColor, Color innerColor, int sides = 0, float startAngle = 0f, float endAngle = (float)Math.PI * 2f)
	{
		if (sides == 0)
		{
			sides = CalculateOptimalEllipseSides(outerRadius, startAngle, endAngle);
		}
		Vector2 p = Vector2.Zero;
		Vector2 p2 = Vector2.Zero;
		for (int i = 0; i <= sides; i++)
		{
			float x = MathUtils.Lerp(startAngle, endAngle, (float)i / (float)sides);
			Vector2 vector = new Vector2(MathUtils.Sin(x), 0f - MathUtils.Cos(x));
			Vector2 vector2 = center + outerRadius * vector;
			Vector2 vector3 = center + innerRadius * vector;
			if (i > 0)
			{
				QueueTriangle(p, vector2, p2, depth, outerColor, outerColor, innerColor);
				QueueTriangle(vector2, vector3, p2, depth, outerColor, innerColor, innerColor);
			}
			p = vector2;
			p2 = vector3;
		}
	}

	public void QueueTriangle(Vector2 p1, Vector2 p2, Vector2 p3, float depth, Color color)
	{
		int count = TriangleVertices.Count;
		TriangleVertices.Add(new VertexPositionColor(new Vector3(p1.X, p1.Y, depth), color));
		TriangleVertices.Add(new VertexPositionColor(new Vector3(p2.X, p2.Y, depth), color));
		TriangleVertices.Add(new VertexPositionColor(new Vector3(p3.X, p3.Y, depth), color));
		TriangleIndices.Add((ushort)count);
		TriangleIndices.Add((ushort)(count + 1));
		TriangleIndices.Add((ushort)(count + 2));
	}

	public void QueueTriangle(Vector2 p1, Vector2 p2, Vector2 p3, float depth, Color color1, Color color2, Color color3)
	{
		int count = TriangleVertices.Count;
		TriangleVertices.Add(new VertexPositionColor(new Vector3(p1.X, p1.Y, depth), color1));
		TriangleVertices.Add(new VertexPositionColor(new Vector3(p2.X, p2.Y, depth), color2));
		TriangleVertices.Add(new VertexPositionColor(new Vector3(p3.X, p3.Y, depth), color3));
		TriangleIndices.Add((ushort)count);
		TriangleIndices.Add((ushort)(count + 1));
		TriangleIndices.Add((ushort)(count + 2));
	}

	public void QueueQuad(Vector2 corner1, Vector2 corner2, float depth, Color color)
	{
		int count = TriangleVertices.Count;
		TriangleVertices.Add(new VertexPositionColor(new Vector3(corner1.X, corner1.Y, depth), color));
		TriangleVertices.Add(new VertexPositionColor(new Vector3(corner1.X, corner2.Y, depth), color));
		TriangleVertices.Add(new VertexPositionColor(new Vector3(corner2.X, corner2.Y, depth), color));
		TriangleVertices.Add(new VertexPositionColor(new Vector3(corner2.X, corner1.Y, depth), color));
		TriangleIndices.Add((ushort)count);
		TriangleIndices.Add((ushort)(count + 1));
		TriangleIndices.Add((ushort)(count + 2));
		TriangleIndices.Add((ushort)(count + 2));
		TriangleIndices.Add((ushort)(count + 3));
		TriangleIndices.Add((ushort)count);
	}

	public void QueueQuad(Vector2 p1, Vector2 p2, Vector2 p3, Vector2 p4, float depth, Color color)
	{
		int count = TriangleVertices.Count;
		TriangleVertices.Count += 4;
		TriangleVertices.Array[count] = new VertexPositionColor(new Vector3(p1.X, p1.Y, depth), color);
		TriangleVertices.Array[count + 1] = new VertexPositionColor(new Vector3(p2.X, p2.Y, depth), color);
		TriangleVertices.Array[count + 2] = new VertexPositionColor(new Vector3(p3.X, p3.Y, depth), color);
		TriangleVertices.Array[count + 3] = new VertexPositionColor(new Vector3(p4.X, p4.Y, depth), color);
		int count2 = TriangleIndices.Count;
		TriangleIndices.Count += 6;
		TriangleIndices.Array[count2] = (ushort)count;
		TriangleIndices.Array[count2 + 1] = (ushort)(count + 1);
		TriangleIndices.Array[count2 + 2] = (ushort)(count + 2);
		TriangleIndices.Array[count2 + 3] = (ushort)(count + 2);
		TriangleIndices.Array[count2 + 4] = (ushort)(count + 3);
		TriangleIndices.Array[count2 + 5] = (ushort)count;
	}

	public void QueueQuad(Vector2 p1, Vector2 p2, Vector2 p3, Vector2 p4, float depth, Color color1, Color color2, Color color3, Color color4)
	{
		int count = TriangleVertices.Count;
		TriangleVertices.Count += 4;
		TriangleVertices.Array[count] = new VertexPositionColor(new Vector3(p1.X, p1.Y, depth), color1);
		TriangleVertices.Array[count + 1] = new VertexPositionColor(new Vector3(p2.X, p2.Y, depth), color2);
		TriangleVertices.Array[count + 2] = new VertexPositionColor(new Vector3(p3.X, p3.Y, depth), color3);
		TriangleVertices.Array[count + 3] = new VertexPositionColor(new Vector3(p4.X, p4.Y, depth), color4);
		int count2 = TriangleIndices.Count;
		TriangleIndices.Count += 6;
		TriangleIndices.Array[count2] = (ushort)count;
		TriangleIndices.Array[count2 + 1] = (ushort)(count + 1);
		TriangleIndices.Array[count2 + 2] = (ushort)(count + 2);
		TriangleIndices.Array[count2 + 3] = (ushort)(count + 2);
		TriangleIndices.Array[count2 + 4] = (ushort)(count + 3);
		TriangleIndices.Array[count2 + 5] = (ushort)count;
	}

	public void Flush(bool clearAfterFlush = true)
	{
		Flush(Vector4.One, clearAfterFlush);
	}

	public void Flush(Vector4 color, bool clearAfterFlush = true)
	{
		Flush(PrimitivesRenderer2D.ViewportMatrix(), color, clearAfterFlush);
	}

	private static int CalculateOptimalEllipseSides(Vector2 radius, float startAngle, float endAngle)
	{
		float num = MathUtils.Max(MathUtils.Abs(radius.X), MathUtils.Abs(radius.Y));
		if (num > 0.33f)
		{
			float num2 = MathUtils.Abs(endAngle - startAngle);
			return (int)MathUtils.Clamp(MathUtils.Ceiling(num2 / (2f * MathUtils.Acos(1f - 0.33f / num))), 3f, 1000f);
		}
		return 3;
	}
}
