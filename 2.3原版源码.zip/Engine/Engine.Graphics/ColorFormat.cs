namespace Engine.Graphics;

public enum ColorFormat
{
	Rgba8888,
	Rgba5551,
	Rgb565,
	R8
}
