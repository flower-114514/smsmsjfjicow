namespace Engine.Graphics;

public enum IndexFormat
{
	SixteenBits,
	ThirtyTwoBits
}
