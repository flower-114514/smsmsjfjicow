using Engine.Media;

namespace Engine.Graphics;

public sealed class PrimitivesRenderer2D : BasePrimitivesRenderer<FlatBatch2D, TexturedBatch2D, FontBatch2D>
{
	public static Matrix ViewportMatrix()
	{
		Viewport viewport = Display.Viewport;
		float num = 1f / (float)viewport.Width;
		float num2 = 1f / (float)viewport.Height;
		return new Matrix(2f * num, 0f, 0f, 0f, 0f, -2f * num2, 0f, 0f, 0f, 0f, 1f, 0f, -1f, 1f, 0f, 1f);
	}

	public FlatBatch2D FlatBatch(int layer = 0, DepthStencilState depthStencilState = null, RasterizerState rasterizerState = null, BlendState blendState = null)
	{
		depthStencilState = depthStencilState ?? DepthStencilState.None;
		rasterizerState = rasterizerState ?? RasterizerState.CullNoneScissor;
		blendState = blendState ?? BlendState.AlphaBlend;
		return FindFlatBatch(layer, depthStencilState, rasterizerState, blendState);
	}

	public TexturedBatch2D TexturedBatch(Texture2D texture, bool useAlphaTest = false, int layer = 0, DepthStencilState depthStencilState = null, RasterizerState rasterizerState = null, BlendState blendState = null, SamplerState samplerState = null)
	{
		depthStencilState = depthStencilState ?? DepthStencilState.None;
		rasterizerState = rasterizerState ?? RasterizerState.CullNoneScissor;
		blendState = blendState ?? BlendState.AlphaBlend;
		samplerState = samplerState ?? SamplerState.LinearClamp;
		return FindTexturedBatch(texture, useAlphaTest, layer, depthStencilState, rasterizerState, blendState, samplerState);
	}

	public FontBatch2D FontBatch(BitmapFont font = null, int layer = 0, DepthStencilState depthStencilState = null, RasterizerState rasterizerState = null, BlendState blendState = null, SamplerState samplerState = null)
	{
		font = font ?? BitmapFont.DebugFont;
		depthStencilState = depthStencilState ?? DepthStencilState.None;
		rasterizerState = rasterizerState ?? RasterizerState.CullNoneScissor;
		blendState = blendState ?? BlendState.AlphaBlend;
		samplerState = samplerState ?? SamplerState.LinearClamp;
		return FindFontBatch(font, layer, depthStencilState, rasterizerState, blendState, samplerState);
	}

	public void Flush(bool clearAfterFlush = true, int maxLayer = 2147483647)
	{
		Flush(Vector4.One, clearAfterFlush, maxLayer);
	}

	public void Flush(Vector4 color, bool clearAfterFlush = true, int maxLayer = 2147483647)
	{
		Flush(ViewportMatrix(), color, clearAfterFlush, maxLayer);
	}
}
