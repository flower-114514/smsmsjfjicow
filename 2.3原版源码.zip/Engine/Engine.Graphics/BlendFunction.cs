namespace Engine.Graphics;

public enum BlendFunction
{
	Add,
	Subtract,
	ReverseSubtract
}
