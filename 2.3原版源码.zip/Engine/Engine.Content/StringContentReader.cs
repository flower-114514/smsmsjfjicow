using System;
using System.IO;

namespace Engine.Content;

[ContentReader("System.String")]
public class StringContentReader : IContentReader
{
	public object Read(ContentStream stream, object existingObject)
	{
		if (existingObject == null)
		{
			BinaryReader binaryReader = new BinaryReader(stream);
			return binaryReader.ReadString();
		}
		throw new NotSupportedException();
	}
}
