using System;
using System.IO;
using System.Xml.Linq;

namespace Engine.Content;

[ContentReader("System.Xml.Linq.XElement")]
public class XElementContentReader : IContentReader
{
	public object Read(ContentStream stream, object existingObject)
	{
		if (existingObject == null)
		{
			BinaryReader binaryReader = new BinaryReader(stream);
			string s = binaryReader.ReadString();
			return XElement.Load(new StringReader(s));
		}
		throw new NotSupportedException();
	}
}
