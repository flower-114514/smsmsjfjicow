using System;

namespace Engine.Content;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
public class OptionalAttribute : Attribute
{
}
