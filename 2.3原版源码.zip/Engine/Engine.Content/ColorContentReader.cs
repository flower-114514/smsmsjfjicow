using System;
using Engine.Serialization;

namespace Engine.Content;

[ContentReader("Engine.Color")]
public class ColorContentReader : IContentReader
{
	public object Read(ContentStream stream, object existingObject)
	{
		if (existingObject == null)
		{
			EngineBinaryReader engineBinaryReader = new EngineBinaryReader(stream);
			return engineBinaryReader.ReadColor();
		}
		throw new NotSupportedException();
	}
}
