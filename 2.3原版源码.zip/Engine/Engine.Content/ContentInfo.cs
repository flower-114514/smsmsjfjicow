namespace Engine.Content;

public struct ContentInfo
{
	public string Name;

	public string TypeName;
}
