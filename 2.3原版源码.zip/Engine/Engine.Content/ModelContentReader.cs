using System.IO;
using Engine.Graphics;
using Engine.Media;

namespace Engine.Content;

[ContentReader("Engine.Graphics.Model")]
public class ModelContentReader : IContentReader
{
	public object Read(ContentStream stream, object existingObject)
	{
		BinaryReader binaryReader = new BinaryReader(stream);
		bool keepSourceVertexDataInTags = binaryReader.ReadBoolean();
		ModelData modelData = ModelDataContentReader.ReadModelData(stream);
		if (existingObject == null)
		{
			return Model.Load(modelData, keepSourceVertexDataInTags);
		}
		Model model = (Model)existingObject;
		model.Initialize(modelData, keepSourceVertexDataInTags);
		return model;
	}
}
