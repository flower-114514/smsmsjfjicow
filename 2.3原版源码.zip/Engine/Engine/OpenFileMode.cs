namespace Engine;

public enum OpenFileMode
{
	Read,
	ReadWrite,
	Create,
	CreateOrOpen
}
