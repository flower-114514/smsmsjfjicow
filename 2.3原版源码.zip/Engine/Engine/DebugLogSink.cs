namespace Engine;

public class DebugLogSink : ILogSink
{
	public LogType MinimumLogType { get; set; }

	public void Log(LogType logType, string message)
	{
		if (logType > MinimumLogType)
		{
			switch (logType)
			{
			case LogType.Debug:
			{
				string empty = "DEBUG: ";
				break;
			}
			case LogType.Verbose:
			{
				string empty = "INFO: ";
				break;
			}
			case LogType.Information:
			{
				string empty = "INFO: ";
				break;
			}
			case LogType.Warning:
			{
				string empty = "WARNING: ";
				break;
			}
			case LogType.Error:
			{
				string empty = "ERROR: ";
				break;
			}
			default:
			{
				string empty = string.Empty;
				break;
			}
			}
		}
	}

	public void Dispose()
	{
	}
}
