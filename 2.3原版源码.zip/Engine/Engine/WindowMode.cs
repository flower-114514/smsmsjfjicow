namespace Engine;

public enum WindowMode
{
	Resizable,
	Fixed,
	Borderless,
	Fullscreen
}
