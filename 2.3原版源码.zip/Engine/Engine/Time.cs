using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace Engine;

public static class Time
{
	private struct DelayedExecutionRequest
	{
		public double Time;

		public int FramesCount;

		public Action Action;
	}

	private static long m_applicationStartTicks = Stopwatch.GetTimestamp();

	private static List<DelayedExecutionRequest> m_delayedExecutionsRequests = new List<DelayedExecutionRequest>();

	private static int m_fpsStartFrameIndex;

	private static double m_fpsStartTime;

	private static float m_fpsCpuTime;

	public static int FrameIndex { get; private set; }

	public static double RealTime => (double)(Stopwatch.GetTimestamp() - m_applicationStartTicks) / (double)Stopwatch.Frequency;

	public static double PreviousFrameStartTime { get; private set; }

	public static double FrameStartTime { get; private set; }

	public static float PreviousFrameDuration { get; private set; }

	public static float FrameDuration { get; private set; }

	public static float CpuFrameDuration { get; private set; }

	public static float AverageFrameDuration { get; private set; }

	public static float AverageCpuFrameDuration { get; private set; }

	public static bool SingleEvent(double time)
	{
		if (FrameStartTime >= time)
		{
			return PreviousFrameStartTime < time;
		}
		return false;
	}

	public static bool PeriodicEvent(double period, double offset)
	{
		double num = FrameStartTime - offset;
		double num2 = MathUtils.Floor(num / period) * period;
		if (num >= num2)
		{
			return num - (double)FrameDuration < num2;
		}
		return false;
	}

	public static void QueueTimeDelayedExecution(double time, Action action)
	{
		m_delayedExecutionsRequests.Add(new DelayedExecutionRequest
		{
			Time = time,
			FramesCount = -1,
			Action = action
		});
	}

	public static void QueueFrameCountDelayedExecution(int framesCount, Action action)
	{
		m_delayedExecutionsRequests.Add(new DelayedExecutionRequest
		{
			Time = -1.0,
			FramesCount = framesCount,
			Action = action
		});
	}

	internal static void BeforeFrame()
	{
		double realTime = RealTime;
		PreviousFrameDuration = FrameDuration;
		FrameDuration = (float)(realTime - FrameStartTime);
		PreviousFrameStartTime = FrameStartTime;
		FrameStartTime = realTime;
		if (FrameStartTime >= m_fpsStartTime + 1.0)
		{
			int num = FrameIndex - m_fpsStartFrameIndex;
			AverageFrameDuration = (float)(FrameStartTime - m_fpsStartTime) / (float)num;
			AverageCpuFrameDuration = m_fpsCpuTime / (float)num;
			m_fpsStartTime = FrameStartTime;
			m_fpsCpuTime = 0f;
			m_fpsStartFrameIndex = FrameIndex;
		}
		int num2 = 0;
		while (num2 < m_delayedExecutionsRequests.Count)
		{
			DelayedExecutionRequest delayedExecutionRequest = m_delayedExecutionsRequests[num2];
			if ((delayedExecutionRequest.Time >= 0.0 && FrameStartTime >= delayedExecutionRequest.Time) || (delayedExecutionRequest.FramesCount >= 0 && FrameIndex >= delayedExecutionRequest.FramesCount))
			{
				m_delayedExecutionsRequests.RemoveAt(num2);
				delayedExecutionRequest.Action();
			}
			else
			{
				num2++;
			}
		}
	}

	internal static void AfterFrame()
	{
		CpuFrameDuration = (float)(RealTime - FrameStartTime);
		m_fpsCpuTime += CpuFrameDuration;
		FrameIndex++;
	}
}
