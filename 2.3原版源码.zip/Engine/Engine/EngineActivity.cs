using System;
using System.Collections.Generic;
using System.IO.Compression;
using System.Reflection;
using System.Threading;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Media;
using Android.OS;
using Android.Views;

namespace Engine;

public class EngineActivity : Activity
{
	internal static EngineActivity m_activity;

	public event Action Paused;

	public event Action Resumed;

	public event Action Destroyed;

	public event Action<Intent> NewIntent;

	public event Action<int> PermissionsChanged;

	public event Action<TrimMemory> TrimMemory;

	public EngineActivity()
	{
		m_activity = this;
	}

	private HashSet<string> ListAppAssemblies()
	{
		HashSet<string> hashSet = new HashSet<string>();
		using ZipArchive zipArchive = ZipFile.OpenRead(ApplicationInfo.SourceDir);
		foreach (ZipArchiveEntry entry in zipArchive.Entries)
		{
			string text = entry.Name.ToLower();
			if (entry.FullName.StartsWith("assemblies/") && text.EndsWith(".dll"))
			{
				hashSet.Add(entry.Name);
			}
			else if (text.StartsWith("libaot-") && text.EndsWith(".so"))
			{
				hashSet.Add(entry.Name.Substring(7, entry.Name.Length - 7 - 3));
			}
		}
		return hashSet;
	}

	private MethodInfo FindMainMethod(string assemblyName)
	{
		try
		{
			Assembly assembly = Assembly.Load(assemblyName);
			Type[] types = assembly.GetTypes();
			foreach (Type type in types)
			{
				MethodInfo method = type.GetMethod("Main", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
				if (method != null)
				{
					List<object> list = new List<object>();
					ParameterInfo[] parameters = method.GetParameters();
					if (parameters.Length == 0)
					{
						return method;
					}
					if (parameters.Length == 1 && !(parameters[0].ParameterType != typeof(string[])))
					{
						return method;
					}
				}
			}
		}
		catch
		{
		}
		return null;
	}

	private MethodInfo FindMainMethod()
	{
		try
		{
			ApplicationInfo applicationInfo = PackageManager.GetApplicationInfo(PackageName, PackageInfoFlags.MetaData);
			string @string = applicationInfo.MetaData.GetString("MainAssembly");
			if (!string.IsNullOrEmpty(@string))
			{
				MethodInfo methodInfo = FindMainMethod(@string);
				if (methodInfo != null)
				{
					return methodInfo;
				}
			}
		}
		catch
		{
		}
		foreach (string item in ListAppAssemblies())
		{
			if (!(item == "mscorlib.dll") && !(item == "Engine.dll") && !item.Contains("OpenTK-") && !item.StartsWith("Java.") && !item.StartsWith("Mono.") && !item.StartsWith("System."))
			{
				MethodInfo methodInfo2 = FindMainMethod(item);
				if (methodInfo2 != null)
				{
					return methodInfo2;
				}
			}
		}
		throw new Exception("Cannot find static Main method.");
	}

	protected override void OnCreate(Bundle savedInstanceState)
	{
		base.OnCreate(savedInstanceState);
		base.VolumeControlStream = Stream.Music;
		RequestWindowFeature(WindowFeatures.NoTitle);
		Window.AddFlags(WindowManagerFlags.Fullscreen);
		MethodInfo methodInfo = FindMainMethod();
		if (methodInfo.GetParameters().Length == 0)
		{
			methodInfo.Invoke(null, null);
			return;
		}
		methodInfo.Invoke(null, new object[1] { new string[0] });
	}

	protected override void OnNewIntent(Intent intent)
	{
		base.OnNewIntent(intent);
		this.NewIntent?.Invoke(intent);
	}

	public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Permission[] grantResults)
	{
		this.PermissionsChanged?.Invoke(requestCode);
	}

	protected override void OnPause()
	{
		base.OnPause();
		this.Paused?.Invoke();
	}

	protected override void OnResume()
	{
		base.OnResume();
		this.Resumed?.Invoke();
	}

	protected override void OnDestroy()
	{
		try
		{
			base.OnDestroy();
			this.Destroyed?.Invoke();
		}
		finally
		{
			Thread.Sleep(250);
			System.Environment.Exit(0);
		}
	}

	public override void OnTrimMemory(TrimMemory level)
	{
		base.OnTrimMemory(level);
		this.TrimMemory?.Invoke(level);
	}
}
