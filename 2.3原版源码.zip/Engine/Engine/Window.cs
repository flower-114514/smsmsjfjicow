using System;
using System.Threading.Tasks;
using Android.Content;
using Android.OS;
using Engine.Audio;
using Engine.Graphics;
using Engine.Input;

namespace Engine;

public static class Window
{
	private enum State
	{
		Uncreated,
		Inactive,
		Active
	}

	private static State m_state = State.Uncreated;

	private static bool m_contextLost;

	internal static bool m_focusRegained;

	private static int m_presentationInterval = 1;

	private static double m_frameStartTime;

	public static bool IsCreated => m_state != State.Uncreated;

	public static bool IsActive => m_state == State.Active;

	public static EngineActivity Activity => EngineActivity.m_activity;

	public static EngineView View { get; private set; }

	public static Point2 ScreenSize => new Point2(EngineActivity.m_activity.Resources.DisplayMetrics.WidthPixels, EngineActivity.m_activity.Resources.DisplayMetrics.HeightPixels);

	public static WindowMode WindowMode
	{
		get
		{
			VerifyWindowOpened();
			return WindowMode.Fullscreen;
		}
		set
		{
			VerifyWindowOpened();
		}
	}

	public static Point2 Position
	{
		get
		{
			VerifyWindowOpened();
			return Point2.Zero;
		}
		set
		{
			VerifyWindowOpened();
		}
	}

	public static Point2 Size
	{
		get
		{
			VerifyWindowOpened();
			return new Point2(View.Size.Width, View.Size.Height);
		}
		set
		{
			VerifyWindowOpened();
		}
	}

	public static string Title
	{
		get
		{
			VerifyWindowOpened();
			return string.Empty;
		}
		set
		{
			VerifyWindowOpened();
		}
	}

	public static int PresentationInterval
	{
		get
		{
			VerifyWindowOpened();
			return m_presentationInterval;
		}
		set
		{
			VerifyWindowOpened();
			m_presentationInterval = MathUtils.Clamp(value, 1, 4);
		}
	}

	public static event Action Created;

	public static event Action Resized;

	public static event Action Activated;

	public static event Action Deactivated;

	public static event Action Closed;

	public static event Action BeforeFrame;

	public static event Action Frame;

	public static event Action AfterFrame;

	public static event Action<UnhandledExceptionInfo> UnhandledException;

	public static event Action<Uri> HandleUri;

	public static event Action LowMemory;

	private static void InitializeAll()
	{
		Dispatcher.Initialize();
		Display.Initialize();
		Keyboard.Initialize();
		MultiKeyboard.Initialize();
		Mouse.Initialize();
		MultiMouse.Initialize();
		Touch.Initialize();
		GamePad.Initialize();
		Mixer.Initialize();
	}

	private static void DisposeAll()
	{
		Dispatcher.Dispose();
		Display.Dispose();
		Keyboard.Dispose();
		MultiKeyboard.Dispose();
		Mouse.Dispose();
		MultiMouse.Dispose();
		Touch.Dispose();
		GamePad.Dispose();
		Mixer.Dispose();
	}

	private static void BeforeFrameAll()
	{
		Time.BeforeFrame();
		Dispatcher.BeforeFrame();
		Display.BeforeFrame();
		Keyboard.BeforeFrame();
		MultiKeyboard.BeforeFrame();
		Mouse.BeforeFrame();
		MultiMouse.BeforeFrame();
		Touch.BeforeFrame();
		GamePad.BeforeFrame();
		Mixer.BeforeFrame();
	}

	private static void AfterFrameAll()
	{
		Time.AfterFrame();
		Dispatcher.AfterFrame();
		Display.AfterFrame();
		Keyboard.AfterFrame();
		MultiKeyboard.AfterFrame();
		Mouse.AfterFrame();
		MultiMouse.AfterFrame();
		Touch.AfterFrame();
		GamePad.AfterFrame();
		Mixer.AfterFrame();
	}

	private static void ProcessFrame()
	{
		Window.BeforeFrame?.Invoke();
		BeforeFrameAll();
		try
		{
			Window.Frame?.Invoke();
		}
		finally
		{
			AfterFrameAll();
			Window.AfterFrame?.Invoke();
		}
	}

	public static void Run(int width = 0, int height = 0, WindowMode windowMode = WindowMode.Fullscreen, string title = "")
	{
		if (View != null)
		{
			throw new InvalidOperationException("Window is already opened.");
		}
		AppDomain.CurrentDomain.UnhandledException += delegate(object sender, UnhandledExceptionEventArgs args)
		{
			if (Window.UnhandledException != null)
			{
				Exception ex = args.ExceptionObject as Exception;
				if (ex == null)
				{
					ex = new Exception($"Unknown exception. Additional information: {args.ExceptionObject}");
				}
				Window.UnhandledException(new UnhandledExceptionInfo(ex));
			}
		};
		Log.Information("Android.OS.Build.Display: " + Build.Display);
		Log.Information("Android.OS.Build.Device: " + Build.Device);
		Log.Information("Android.OS.Build.Hardware: " + Build.Hardware);
		Log.Information("Android.OS.Build.Manufacturer: " + Build.Manufacturer);
		Log.Information("Android.OS.Build.Model: " + Build.Model);
		Log.Information("Android.OS.Build.Product: " + Build.Product);
		Log.Information("Android.OS.Build.Brand: " + Build.Brand);
		Log.Information("Android.OS.Build.VERSION.SdkInt: " + (int)Build.VERSION.SdkInt);
		View = new EngineView(Activity);
		View.ContextSet += ContextSetHandler;
		View.Resize += ResizeHandler;
		View.ContextLost += ContextLostHandler;
		View.RenderFrame += RenderFrameHandler;
		Activity.Paused += PausedHandler;
		Activity.Resumed += ResumedHandler;
		Activity.Destroyed += DestroyedHandler;
		Activity.NewIntent += NewIntentHandler;
		Activity.TrimMemory += TrimMemoryHandler;
		Activity.SetContentView(View);
		View.RequestFocus();
		View.Run();
	}

	public static void Close()
	{
		VerifyWindowOpened();
		Activity.Finish();
	}

	private static void VerifyWindowOpened()
	{
		if (View == null)
		{
			throw new InvalidOperationException("Window is not opened.");
		}
	}

	private static void PausedHandler()
	{
		if (m_state == State.Active)
		{
			m_state = State.Inactive;
			Keyboard.Clear();
			Mixer.Deactivate();
			if (Window.Deactivated != null)
			{
				Window.Deactivated();
			}
		}
	}

	private static void ResumedHandler()
	{
		if (m_state == State.Inactive)
		{
			m_state = State.Active;
			Mixer.Activate();
			View.EnableImmersiveMode();
			Window.Activated?.Invoke();
		}
	}

	private static void DestroyedHandler()
	{
		if (m_state == State.Active)
		{
			m_state = State.Inactive;
			Window.Deactivated?.Invoke();
		}
		m_state = State.Uncreated;
		Window.Closed?.Invoke();
		DisposeAll();
	}

	private static void NewIntentHandler(Intent intent)
	{
		if (Window.HandleUri != null && intent != null)
		{
			Uri uriFromIntent = GetUriFromIntent(intent);
			if (uriFromIntent != null)
			{
				Window.HandleUri(uriFromIntent);
			}
		}
	}

	private static void TrimMemoryHandler(TrimMemory level)
	{
		if (level >= TrimMemory.RunningCritical)
		{
			Window.LowMemory?.Invoke();
		}
	}

	private static void ResizeHandler(object sender, EventArgs args)
	{
		if (m_state != 0)
		{
			Display.Resize();
			Window.Resized?.Invoke();
		}
	}

	private static void ContextSetHandler(object sender, EventArgs args)
	{
		if (m_contextLost)
		{
			m_contextLost = false;
			Display.HandleDeviceReset();
		}
	}

	private static void ContextLostHandler(object sender, EventArgs args)
	{
		m_contextLost = true;
		Display.HandleDeviceLost();
	}

	private static void RenderFrameHandler(object sender, EventArgs args)
	{
		if (m_state == State.Uncreated)
		{
			InitializeAll();
			m_state = State.Inactive;
			Window.Created?.Invoke();
			m_state = State.Active;
			Window.Activated?.Invoke();
			NewIntentHandler(Activity.Intent);
		}
		if (m_state != State.Active)
		{
			return;
		}
		BeforeFrameAll();
		Window.Frame?.Invoke();
		AfterFrameAll();
		View.GraphicsContext.SwapBuffers();
		if (m_presentationInterval >= 2)
		{
			double num = Time.RealTime - m_frameStartTime;
			int num2 = (int)(1000.0 * ((double)((float)m_presentationInterval / 60f) - num));
			if (num2 > 0)
			{
				Task.Delay(num2).Wait();
			}
		}
		m_frameStartTime = Time.RealTime;
		if (m_focusRegained)
		{
			m_focusRegained = false;
			View.EnableImmersiveMode();
		}
	}

	private static Uri GetUriFromIntent(Intent intent)
	{
		Uri result = null;
		if (!string.IsNullOrEmpty(intent.DataString))
		{
			Uri.TryCreate(intent.DataString, UriKind.RelativeOrAbsolute, out result);
		}
		return result;
	}
}
