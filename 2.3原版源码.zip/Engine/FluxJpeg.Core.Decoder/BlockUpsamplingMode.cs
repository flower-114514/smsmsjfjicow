namespace FluxJpeg.Core.Decoder;

internal enum BlockUpsamplingMode
{
	BoxFilter,
	Interpolate
}
