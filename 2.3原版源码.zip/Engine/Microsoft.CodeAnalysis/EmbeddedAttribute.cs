using System;
using System.Runtime.CompilerServices;

namespace Microsoft.CodeAnalysis;

[CompilerGenerated]
[Embedded]
internal sealed class EmbeddedAttribute : Attribute
{
}
