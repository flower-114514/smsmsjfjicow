namespace Engine.Audio;

public enum SoundState
{
	Stopped,
	Playing,
	Paused,
	Disposed
}
