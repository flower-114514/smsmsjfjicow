namespace FluxJpeg.Core;

internal enum ColorSpace
{
	Gray,
	YCbCr,
	RGB
}
