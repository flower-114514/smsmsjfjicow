using System;

namespace FluxJpeg.Core;

internal class ResizeNotNeededException : Exception
{
}
