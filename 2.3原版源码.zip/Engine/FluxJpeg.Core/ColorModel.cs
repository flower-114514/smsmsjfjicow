namespace FluxJpeg.Core;

internal struct ColorModel
{
	public ColorSpace colorspace;

	public bool Opaque;
}
