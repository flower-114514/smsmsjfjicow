using System;

namespace FluxJpeg.Core;

internal class ResizeProgressChangedEventArgs : EventArgs
{
	public double Progress;
}
